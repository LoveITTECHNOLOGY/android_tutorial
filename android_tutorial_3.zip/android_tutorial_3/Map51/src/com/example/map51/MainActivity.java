package com.example.map51;



import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private TextView tv_location;
    private Context context;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;
        tv_location = (TextView) findViewById(R.id.textView1);

        //��ȡLocationManager
        LocationManager lManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        /**
         * ��1:ѡ��λ�ķ�ʽ
         * ��2:��λ�ļ��ʱ��
         * ��3:��λ�øı����ʱ�������¶�λ
         * ��4:λ�õĻص�����
         */
        lManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1, 0, new LocationListener() {
            //��λ�øı��ʱ�����
            @Override
            public void onLocationChanged(Location location) {

                //����
                double longitude = location.getLongitude();
                //γ��
                double latitude = location.getLatitude();

                //����
                double altitude = location.getAltitude();
                //ϵͳʱ��
                double time = location.getTime();
                //�ٶ�
                double speed = location.getSpeed();
                

                tv_location.setText("����:==>"+longitude+" \n γ��==>"+latitude
                		+"\n"+"����==>"+altitude
                		+" \n ʱ��:==>"+time+" \n �ٶ�==>"+speed);
            }

            //��GPS״̬�����ı��ʱ�����
            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

                switch (status){

                    case LocationProvider.AVAILABLE:

                        Toast.makeText(context,"��ǰGPSΪ����״̬!",Toast.LENGTH_SHORT).show();

                        break;

                    case LocationProvider.OUT_OF_SERVICE:

                        Toast.makeText(context,"��ǰGPS���ڷ�����",Toast.LENGTH_SHORT).show();

                        break;

                    case LocationProvider.TEMPORARILY_UNAVAILABLE:

                        Toast.makeText(context,"��ǰGPSΪ��ͣ����״̬",Toast.LENGTH_SHORT).show();
                        break;
                }

            }

            //GPS������ʱ�����
            @Override
           public void onProviderEnabled(String provider) {

                Toast.makeText(context,"GPS������",Toast.LENGTH_SHORT).show();

            }

            //GPS�رյ�ʱ�����
            @Override
            public void onProviderDisabled(String provider) {

                Toast.makeText(context,"GPS�ر���",Toast.LENGTH_SHORT).show();

            }
        });
    }
}
