package com.example.imagecheck51;


import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;


public class MainActivity extends Activity {

	
	Canvas canvas=new Canvas();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
   //     setContentView(R.layout.activity_main);
        setContentView(new CustomView1(this));
   //     iv=(ImageView) findViewById(R.id.imageView1);
        
    }
}

    class  CustomView1 extends View
    {
    	int i=0,j1=0,j2=0;
    	Paint paint;
    	public CustomView1(Context context)
    	{
    		super(context);
    		paint = new Paint(); //����һ����ˢ��С��3�Ļ�ɫ�Ļ���
 		
    		paint.setStrokeWidth(3);

    	}
    	protected void onDraw(Canvas canvas) 
    	{
    		i+=10;
    		if(j1>600)
    			j1=0;
    		if(j2>800)
    			j2=0;
    		j1+=10;
    		j2+=10;
    		paint.setColor(Color.YELLOW);
    		canvas.drawCircle(600, 600, 200, paint);
    		RectF oval=new RectF();
    		oval.left=100;
    		oval.top=100;
    		oval.right=400;
    		oval.bottom=300;
    		paint.setColor(Color.RED);
    		canvas.drawOval(oval, paint);
    		canvas.drawLine(600, 600, (float)(600+Math.sin(Math.PI*i/180)*200),(float)(600-Math.cos(Math.PI*i/180)*200), paint);
    	//	canvas.drawLine(700, 700, 600,600, paint);
    		postInvalidateDelayed(100);
    	}

    }




