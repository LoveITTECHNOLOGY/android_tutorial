package com.example.lineracceleration51;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener{

	private SensorManager manager;
	private Sensor sensor;
	private TextView text;
	private int mRotation;
	String s;
	double f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        manager=(SensorManager)this.getSystemService(SENSOR_SERVICE);
        sensor=manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        text=(TextView)findViewById(R.id.textView1);
      //  WindowManager window=(WindowManager)this.getSystemService(WINDOW_SERVICE);
      //  mRotation=window.getDefaultDisplay().getRotation();
        
    }

    public void onResume()
    {
    	manager.registerListener(this, sensor,SensorManager.SENSOR_DELAY_UI);
    	super.onResume();
    }
    
    public void onPause()
    {
    	manager.unregisterListener(this,sensor);
    	super.onPause();
    }
    
    public void onAccuracyChanged(Sensor sensor,int accuracy)
    {   }
    
    public void onSensorChanged(SensorEvent event)
    {
    	s="X����ٶȣ�"+event.values[0]+"\nY����ٶȣ�"+event.values[1]
    			+"\nZ����ٶȣ�"+event.values[2];
    	float x=event.values[0];
    	float y=event.values[1];
    	float z=event.values[2];
    	float a=(x*x+y*y+z*z);
    	float r=(float) Math.sqrt(a);
    	f=a *3/2;

    	//���ش������ľ���
    	text.setText(s+"\n"+"�������ľ���:"+sensor.getResolution()
    				  +"\n"+"�����������ֵ:"+sensor.getMaximumRange()
    				  +"\n"+"������������:"+sensor.getName()
    				  +"\n"+"������������:"+sensor.getType()
    				  +"\n"+"�������Ĺ���:"+sensor.getPower()
    				  +"\n"+"��Ӧ����:"+sensor.getVendor()
    				  +"\n"+"�������İ汾��:"+sensor.getVersion()+"\n"+"F�Ĵ�СΪ:"+f
    			);
    	//text.setText(s);
    	text.invalidate();
    }
}
