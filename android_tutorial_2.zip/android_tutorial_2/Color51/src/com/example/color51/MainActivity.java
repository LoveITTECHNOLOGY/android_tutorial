package com.example.color51;



import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;

import android.util.Log;
import android.widget.TextView;
 
public class MainActivity extends Activity {
private SensorManager sensorManager;
private TextView lightLevel;
@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
lightLevel = (TextView) findViewById(R.id.light_level);
sensorManager = (SensorManager) getSystemService(Context.
SENSOR_SERVICE);
Sensor sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
sensorManager.registerListener(listener, sensor, SensorManager.
SENSOR_DELAY_NORMAL);
}
@Override
protected void onDestroy() {
super.onDestroy();
if (sensorManager != null) {
sensorManager.unregisterListener(listener);
}
}
private SensorEventListener listener = new SensorEventListener() {
@Override
public void onSensorChanged(SensorEvent event) {
// values�����е�һ���±��ֵ���ǵ�ǰ�Ĺ���ǿ��
float value = event.values[0];
int a=(int)(value/10);

switch(a) {
case 1:lightLevel.setBackgroundColor(Color.BLACK);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n���Ǻ�ɫ");
break;

case 2:lightLevel.setBackgroundColor(Color.BLUE);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n������ɫ");
break;

case 3:lightLevel.setBackgroundColor(Color.RED);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n���Ǻ�ɫ");
break;
case 4:
case 5:
case 6:
case 7:lightLevel.setBackgroundColor(Color.GREEN);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n������ɫ");
break;

case 8:lightLevel.setBackgroundColor(Color.YELLOW);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n���ǻ�ɫɫ");
break;

case 9:lightLevel.setBackgroundColor(Color.WHITE);
lightLevel.setText("��ǰ����ǿ��Ϊ " + value + " lx"+"\n���ǰ�ɫ");
break;

}

}
@Override
public void onAccuracyChanged(Sensor sensor, int accuracy) {
}
};
}
