package com.example.accelerometer51;



//���ٶȴ�����
import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener{

	private SensorManager manager;
	private Sensor sensor;
	private TextView text;
	private int mRotation;
	String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        manager=(SensorManager)this.getSystemService(SENSOR_SERVICE);
        sensor=manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        text=(TextView)findViewById(R.id.textView1);
      //  WindowManager window=(WindowManager)this.getSystemService(WINDOW_SERVICE);
      //  mRotation=window.getDefaultDisplay().getRotation();
        
    }

    public void onResume()
    {
    	manager.registerListener(this, sensor,SensorManager.SENSOR_DELAY_UI);
    	super.onResume();
    }
    
    public void onPause()
    {
    	manager.unregisterListener(this,sensor);
    	super.onPause();
    }
    
    public void onAccuracyChanged(Sensor sensor,int accuracy)
    {   }
    
    public void onSensorChanged(SensorEvent event)
    {
    	s="X����ٶȣ�"+event.values[0]+"\nY����ٶȣ�"+event.values[1]
    			+"\nZ����ٶȣ�"+event.values[2];
    	text.setText(s);
    	text.invalidate();
    }
}
