package com.example.sharedpreferences51;


import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

	SharedPreferences sp;
	SharedPreferences.Editor edit;
	EditText et1,et2;
	Button b1,b2;
	TextView tv3;
	String s1,s2,s3,s4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.editText1);
        et2=(EditText)findViewById(R.id.editText2);
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        tv3=(TextView)findViewById(R.id.textView3);
        
        sp=getSharedPreferences("a",MODE_PRIVATE);  //���ش洢�ռ�������a.xml���������ݶ�д
        edit=sp.edit();
        
        b1.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View v)
        	{
                s1=et1.getText().toString();
                s2=et2.getText().toString();
               /////////////////////////
                edit.putString("name1", s1);
                edit.putString("pass1", s2);
                edit.commit();
                /////////////////////////
                et1.setText("");
                et2.setText("");
        	}
        });
        
        
        b2.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View v)
        	{
        		s3=sp.getString("name1", "");
        		s4=sp.getString("pass1", "");
        		
        		et1.setText(s3);
        		et2.setText(s4);
        	}
        });
        
    }

}
