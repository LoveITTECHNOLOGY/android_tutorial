package com.example.write51;




    
import java.io.FileInputStream;
import java.io.FileOutputStream;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

	EditText et1;
	Button b1,b2,b3;
	String s1;
	TextView tv1;
	int index=0;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.editText1);
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        tv1=(TextView)findViewById(R.id.textView1);
        
        b1.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View v)
        	{
                s1=et1.getText().toString();
                try{
              //  	FileOutputStream fos=
              //  			openFileOutput("a.txt",MODE_PRIVATE);
                	FileOutputStream fos=
                			openFileOutput("a.txt",MODE_APPEND);
                	fos.write(s1.getBytes());
                	fos.write("#".getBytes());
                	fos.flush();
                	fos.close();
                }catch(Exception e){}
                et1.setText("");
        	}
        });
        
        
        
        
        
        
        
        
        b2.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View v)
        	{
        		try{
        			FileInputStream fis=openFileInput("a.txt");
        			byte[] b=new byte[fis.available()];
        			fis.read(b);
        			String str=new String(b);
        			et1.setText(str);
        			
        		}catch(Exception e){}	
        	}
        });
        
        
        
        
        
        
        b3.setOnClickListener(new View.OnClickListener(){
        	public void onClick(View v)
        	{
        		try{
        			FileInputStream fis=openFileInput("a.txt");
        			byte[] b=new byte[fis.available()];
        			fis.read(b);
        			String str=new String(b);
        			String saim=et1.getText().toString();
        			while(str.length()!=0)
        			{
        				index = str.indexOf('#');	
        				String s1=str.substring(0,index);
        				str=str.substring(index+1,str.length());
        				if(s1.contains(saim))
        				{
        					et1.setText(s1);
        				}
        			
        			}	
        			
        		}catch(Exception e){}	
        	}
        });
        
        
        
    }
}
