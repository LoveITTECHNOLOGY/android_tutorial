package com.example.database51;



import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Activity2 extends Activity {

	EditText et1,et2;
	Button b1,b2,b3,b4;
	String s1,s2,s3,s4;
	SQLiteDatabase mydb;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activity2);
		et1=(EditText)findViewById(R.id.editText1);
        et2=(EditText)findViewById(R.id.editText2);
        b1=(Button)findViewById(R.id.button1);
        mydb=SQLiteDatabase.openOrCreateDatabase(getFilesDir()+"/login.db",null);
        ////////////////////////////////
   //     mydb.execSQL("create table info(name text,pass text)"); //�˴���ʾÿ���費ͬ�ı�������Ϊ�޷��ظ�����
        ////////////////////////////////
        b1.setOnClickListener(new View.OnClickListener(){   //�޸�
        	public void onClick(View v)
        	{
        		xiugai1();
        	//	xiugai2();
        	}
        });  
		
	}
	public void xiugai1()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
        mydb.execSQL("update info set pass=? where name=?",new String[]{s2,s1});
        
        et1.setText("");
        et2.setText("");
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity2, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
