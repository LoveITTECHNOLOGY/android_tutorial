package com.example.database51;


//���ݿ���ɾ��ĵ�����
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

	EditText et1,et2;
	Button b1,b2,b3,b4;
	TextView tv1;
	String s1,s2,s3,s4;
	SQLiteDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.editText1);
        et2=(EditText)findViewById(R.id.editText2);
        tv1=(TextView)findViewById(R.id.textView1);
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        ////////////////////////////////
        mydb=SQLiteDatabase.openOrCreateDatabase(getFilesDir()+"/login.db",null);
        ////////////////////////////////
        mydb.execSQL("create table if not exists info(name text,pass text)"); 
    //  mydb.execSQL("create table info(name text,pass text)"); //���г���ÿ���費ͬ�ı�������Ϊ�޷��ظ����ɡ��ʲ��Ƽ�ʹ��
        ////////////////////////////////
        b1.setOnClickListener(new View.OnClickListener(){  // ��¼����ѯ
        	public void onClick(View v)
        	{
        	//	chaxun1();
                chaxun2();
        	}
        });
        
        b2.setOnClickListener(new View.OnClickListener(){   //ע�ᣬ����
        	public void onClick(View v)
        	{
        	
        	//	zengjia1();
        	//	zengjia2();
        		zengjia3();
        	}
        });

        b3.setOnClickListener(new View.OnClickListener(){   //ɾ��
        	public void onClick(View v)
        	{
        		shanchu1();
        	//	shanchu2();
        	}
        });
        
        b4.setOnClickListener(new View.OnClickListener(){   //�޸�
        	public void onClick(View v)
        	{
        		xiugai1();
        	//	xiugai2();
        	}
        });   
    }
    
    
    //////////////////////////////////////////////////
    public void zengjia1()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
        mydb.execSQL("insert into info(name,pass) values('"+s1+"','"+s2+"')");
     /*   mydb.execSQL("insert into info(name,pass,score) values('"
				+s1
				+"','"
				+s2
				+")");   */
        
        et1.setText("");
        et2.setText("");
    }
    /////////////////////////////////////////////////
    public void zengjia2()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
        mydb.execSQL("insert into info(name,pass) values(?,?)",new String[]{s1,s2});
     //   mydb.execSQL("insert into info(name,pass,score) values(?,?,?)",new String[]{s1,s2,s3});
        
        et1.setText("");
        et2.setText("");
    }
    /////////////////////////////////////////////
    public void zengjia3()                 // ����
    {
    	s1=et1.getText().toString();
    	s2=et2.getText().toString();

    	ContentValues cv=new ContentValues();
    	cv.put("name", s1);
    	cv.put("pass", s2);
    	mydb.insert("info", null, cv);

    	et1.setText("");
    	et2.setText("");
    }
    /////////////////////////////////////////////////
   
    
    public void chaxun1()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
       // s3=et3.getText().toString();
       // int s33=Integer.parseInt(s3);
        
        Cursor c=mydb.rawQuery("select * from info where name=?",new String[]{s1});  
    	
        if(c.getCount()==0)
        	Toast.makeText(MainActivity.this,"�û���������",Toast.LENGTH_LONG).show();
        else
        {
        	while(c.moveToNext())
        	{
        		String st2=c.getString(c.getColumnIndex("pass"));
        	//	String st2=c.getString(1));
        	//	int st3=c.getInt(2);   //��ֵ�ֱ�Ϊ0,1,2
        		if(s2.equals(st2))    //s33==st3
        		{
        			Toast.makeText(MainActivity.this,"��½�ɹ���",Toast.LENGTH_LONG).show();
        			Intent in1=new Intent(MainActivity.this,Activity2.class);
            		startActivity(in1);
        		}
        		else
        		{
        			Toast.makeText(MainActivity.this,"���벻��ȷ",Toast.LENGTH_LONG).show();
        		}
        	}
        }

    }
    ////////////////////////////////////////////////////////
    public void chaxun2()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
    	Cursor c=mydb.query("info",null,null,null,null,null,null);
    	while(c.moveToNext())
    	{
    		String st1=c.getString(c.getColumnIndex("name"));
    		String st2=c.getString(c.getColumnIndex("pass"));
    	
    		if(s1.equals(st1)&&s2.equals(st2))
    		{
    			Toast.makeText(MainActivity.this,"��½�ɹ���",Toast.LENGTH_LONG).show();
    			Intent in1=new Intent(MainActivity.this,Activity2.class);
        		startActivity(in1);
    		}	
    	
    		if(c.isLast())
    			Toast.makeText(MainActivity.this,"�û��������벻����",Toast.LENGTH_LONG).show();
    	}
    }
    //////////////////////////////////////////////
    public void shanchu1()
    {
    	s1=et1.getText().toString();

    	mydb.execSQL("delete from info where name=?", new String[]{s1});

    	et1.setText("");
    }
    ////////////////////////////////////////////////////
    public void shanchu2()
    {
    	s1=et1.getText().toString();
    	
        mydb.delete("info", "name=?", new String[]{s1});
        
        et1.setText("");
    }
    
    /////////////////////////////////////////////////////////
    
    public void xiugai1()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
        mydb.execSQL("update info set pass=? where name=?",new String[]{s2,s1});
        
        et1.setText("");
        et2.setText("");
    }
    
    //////////////////////////////////////////////////////
    public void xiugai2()
    {
    	s1=et1.getText().toString();
        s2=et2.getText().toString();
        
        ContentValues cv=new ContentValues();
        cv.put("pass", s2);
        
        mydb.update("info", cv, "name=?", new String[]{s1});
        
        et1.setText("");
        et2.setText("");
    }
}
