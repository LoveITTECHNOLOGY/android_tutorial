/** Automatically generated file. DO NOT MODIFY */
package com.example.database51;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}