package com.example.gyropacket;


//ҡһҡ

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends Activity implements SensorEventListener{
	MediaPlayer m1;
	private SensorManager manager;
	private Sensor sensor;
	private int mRotation;
	String s;
	Canvas canvas=new Canvas();
	CustomView1 cv;
	float x=0,y=0,z=0,xNow=500,yNow=800;
	long t1,t2;   
	double t;
	boolean b=true;
	int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
   //     setContentView(R.layout.activity_main);
        cv=new CustomView1(this);
        setContentView(cv);
        
        manager=(SensorManager)this.getSystemService(SENSOR_SERVICE);
        sensor=manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        WindowManager window=(WindowManager)this.getSystemService(WINDOW_SERVICE);
        mRotation=window.getDefaultDisplay().getRotation();
        t1=System.currentTimeMillis();
        m1=MediaPlayer.create(this, R.raw.a);
        m1.start();
    }
    
    public void onResume()
    {
    	manager.registerListener(this, sensor,SensorManager.SENSOR_DELAY_UI);
    	super.onResume();
    }
    
    public void onPause()
    {
    	manager.unregisterListener(this,sensor);
    	super.onPause();
    }
    
    public void onAccuracyChanged(Sensor sensor,int accuracy)
    {   }
    
    public void onSensorChanged(SensorEvent event)
    {
    	x=event.values[0];
    	y=event.values[1];
    	z=event.values[2];
    	if(z<-3 || z>3)
    	{
    		cv.invalidate();
    		m1.start();
    	}
    }


    class  CustomView1 extends View
    {
    	Paint paint;
    	public CustomView1(Context context)
    	{
    		super(context);
    		paint = new Paint(); //����һ����ˢ��С��3�Ļ�ɫ�Ļ���
    		paint.setColor(Color.RED);
    		paint.setStrokeJoin(Paint.Join.ROUND);
    		paint.setStrokeCap(Paint.Cap.ROUND);
    		paint.setStrokeWidth(3);

    	}
    	
    
    	protected void onDraw(Canvas canvas) 
    	{  		
    		paint.setTextSize(100);
    		i++;
    		canvas.drawText("��ҡ����"+i+"�����!", 200, 300, paint);
    		canvas.drawRect(200,400,50,50,paint);
    			
    //		try{  Thread.sleep(1500);  }catch(Exception e){}
    	}	
    }
}


