/** Automatically generated file. DO NOT MODIFY */
package com.example.gyropacket;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}