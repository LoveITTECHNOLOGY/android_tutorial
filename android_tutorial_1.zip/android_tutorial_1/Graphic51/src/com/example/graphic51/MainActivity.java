package com.example.graphic51;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;


public class MainActivity extends Activity {

	ImageView iv1,iv2;
	Bitmap  bm1,bm2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv1=(ImageView)findViewById(R.id.imageView1);
        iv2=(ImageView)findViewById(R.id.imageView2);
        bm1= BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_launcher);
        bm2=Bitmap.createScaledBitmap(bm1, (int)(bm1.getWidth()*2), 
        		(int)(bm1.getHeight()*4), true);
        
        iv1.setOnClickListener(new OnClickListener() {
        	public void onClick(View arg0) {
        	// TODO Auto-generated method stub
        		     
        		iv1.setImageBitmap(bm2);
        	}
        });
        
        iv2.setOnClickListener(new OnClickListener() {
        	public void onClick(View arg0) {
        	// TODO Auto-generated method stub
        	        
        		iv2.setImageBitmap(bm1);
        	}
        });
       
    }
}
