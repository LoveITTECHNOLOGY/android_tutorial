/** Automatically generated file. DO NOT MODIFY */
package com.example.graphic51;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}