package com.example.gravityscreen51;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.R.integer;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;


public class MainActivity extends Activity implements SensorEventListener {
	private SensorManager manager;
	private Sensor sensor;
	private TextView text;
	private int mRotation;
	String s;
	int g=0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		manager=(SensorManager)this.getSystemService(SENSOR_SERVICE);
		sensor=manager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
		text=(TextView)findViewById(R.id.textView1);
	}
	
	public void onResume(){
		manager.registerListener(this, sensor,SensorManager.SENSOR_DELAY_UI);
	    super.onResume();
	}
	
	public void onPause(){
		manager.unregisterListener(this,sensor);
		super.onPause();
	}
	
	public void onAccuracyChang(Sensor sensor,int accuracy){
		
	}
	
	public void onSensorChanged(SensorEvent event){
		float x,y,z,f,max = 0;
		s="x����ٶ�: "+event.values[0]+"\nY����ٶ�: "+event.values[1]+"\nZ����ٶȣ�"+event.values[2];
		x=event.values[0];
		y=event.values[1];
		z=event.values[2];
		f=(float) (((float) Math.pow(x*x+y*y+z*z, 0.5))*3);
		if (max<f) {
			max=f;
		}
		if (f>10) {
			g++;
		}
	text.setText(s+"\n"+"������"+g);
	text.invalidate();
	}
	

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}
}