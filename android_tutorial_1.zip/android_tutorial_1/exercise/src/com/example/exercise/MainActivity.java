package com.example.exercise;

import org.apache.http.client.entity.UrlEncodedFormEntity;

import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.SearchManager.OnCancelListener;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends Activity {
	private MediaPlayer mediaplayer;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mediaplayer=MediaPlayer.create(MainActivity.this, R.raw.sound);
		Button startButton=(Button) findViewById(R.id.button1);
		startButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mediaplayer.start();
				mediaplayer.setOnCompletionListener(new OnCompletionListener() {
					
					@Override
					public void onCompletion(MediaPlayer arg0) {
						// TODO Auto-generated method stub
						Toast.makeText(MainActivity.this, "��ʼ��������",Toast.LENGTH_SHORT);
						
					}
				});
				
			}
		});
	Button 	pauseButton=(Button) findViewById(R.id.button2);
	pauseButton.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			mediaplayer.pause();
			
		}
	});
		
}
}